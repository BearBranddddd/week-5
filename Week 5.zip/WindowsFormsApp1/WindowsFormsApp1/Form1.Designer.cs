﻿namespace WindowsFormsApp1
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.b_input = new System.Windows.Forms.Button();
            this.tb_ID = new System.Windows.Forms.TextBox();
            this.tb_namatim = new System.Windows.Forms.TextBox();
            this.tb_namastadium = new System.Windows.Forms.TextBox();
            this.tb_kota = new System.Windows.Forms.TextBox();
            this.tb_kapasitas = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.tb_namamanager = new System.Windows.Forms.TextBox();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            this.SuspendLayout();
            // 
            // dataGridView1
            // 
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Location = new System.Drawing.Point(544, 166);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.RowHeadersWidth = 82;
            this.dataGridView1.RowTemplate.Height = 33;
            this.dataGridView1.Size = new System.Drawing.Size(1018, 449);
            this.dataGridView1.TabIndex = 0;
            // 
            // b_input
            // 
            this.b_input.Location = new System.Drawing.Point(273, 474);
            this.b_input.Name = "b_input";
            this.b_input.Size = new System.Drawing.Size(129, 41);
            this.b_input.TabIndex = 1;
            this.b_input.Text = "Input";
            this.b_input.UseVisualStyleBackColor = true;
            this.b_input.Click += new System.EventHandler(this.b_input_Click);
            // 
            // tb_ID
            // 
            this.tb_ID.Enabled = false;
            this.tb_ID.Location = new System.Drawing.Point(247, 166);
            this.tb_ID.Name = "tb_ID";
            this.tb_ID.Size = new System.Drawing.Size(198, 31);
            this.tb_ID.TabIndex = 3;
            // 
            // tb_namatim
            // 
            this.tb_namatim.Location = new System.Drawing.Point(247, 212);
            this.tb_namatim.Name = "tb_namatim";
            this.tb_namatim.Size = new System.Drawing.Size(198, 31);
            this.tb_namatim.TabIndex = 4;
            this.tb_namatim.TextAlignChanged += new System.EventHandler(this.tb_namatim_TextAlignChanged);
            this.tb_namatim.TextChanged += new System.EventHandler(this.tb_namatim_TextChanged);
            // 
            // tb_namastadium
            // 
            this.tb_namastadium.Location = new System.Drawing.Point(247, 261);
            this.tb_namastadium.Name = "tb_namastadium";
            this.tb_namastadium.Size = new System.Drawing.Size(198, 31);
            this.tb_namastadium.TabIndex = 5;
            // 
            // tb_kota
            // 
            this.tb_kota.Location = new System.Drawing.Point(247, 366);
            this.tb_kota.Name = "tb_kota";
            this.tb_kota.Size = new System.Drawing.Size(198, 31);
            this.tb_kota.TabIndex = 6;
            // 
            // tb_kapasitas
            // 
            this.tb_kapasitas.Location = new System.Drawing.Point(247, 314);
            this.tb_kapasitas.Name = "tb_kapasitas";
            this.tb_kapasitas.Size = new System.Drawing.Size(198, 31);
            this.tb_kapasitas.TabIndex = 7;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(84, 169);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(73, 25);
            this.label1.TabIndex = 8;
            this.label1.Text = "Tim ID";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(84, 320);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(107, 25);
            this.label2.TabIndex = 9;
            this.label2.Text = "Kapasitas";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(84, 267);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(152, 25);
            this.label3.TabIndex = 10;
            this.label3.Text = "Nama Stadium";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(84, 215);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(109, 25);
            this.label4.TabIndex = 11;
            this.label4.Text = "Nama Tim";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(84, 372);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(56, 25);
            this.label5.TabIndex = 12;
            this.label5.Text = "Kota";
            // 
            // label6
            // 
            this.label6.AllowDrop = true;
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(84, 428);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(159, 25);
            this.label6.TabIndex = 14;
            this.label6.Text = "Nama Manager";
            // 
            // tb_namamanager
            // 
            this.tb_namamanager.Location = new System.Drawing.Point(247, 422);
            this.tb_namamanager.Name = "tb_namamanager";
            this.tb_namamanager.Size = new System.Drawing.Size(198, 31);
            this.tb_namamanager.TabIndex = 13;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(12F, 25F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1594, 873);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.tb_namamanager);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.tb_kapasitas);
            this.Controls.Add(this.tb_kota);
            this.Controls.Add(this.tb_namastadium);
            this.Controls.Add(this.tb_namatim);
            this.Controls.Add(this.tb_ID);
            this.Controls.Add(this.b_input);
            this.Controls.Add(this.dataGridView1);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.Button b_input;
        private System.Windows.Forms.TextBox tb_ID;
        private System.Windows.Forms.TextBox tb_namatim;
        private System.Windows.Forms.TextBox tb_namastadium;
        private System.Windows.Forms.TextBox tb_kota;
        private System.Windows.Forms.TextBox tb_kapasitas;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox tb_namamanager;
    }
}

