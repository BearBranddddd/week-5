﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp1
{
    //BERNARDO FREDERICK KOWE - 0706022310049
    // komponen form belum diganti
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        DataTable Tim = new DataTable();
        private void Form1_Load(object sender, EventArgs e)
        {
            Tim.Columns.Add("ID Tim");
            Tim.Columns.Add("Nama Tim");
            Tim.Columns.Add("Nama Stadium");
            Tim.Columns.Add("Kapasitas");
            Tim.Columns.Add("Kota");
            Tim.Columns.Add("Nama Manager");

            Tim.Rows.Add("J01", "Juventus", "Mndalika", "100", "Surabaya", "Bernard");
            dataGridView1.DataSource = Tim;

        }

        private void b_input_Click(object sender, EventArgs e)
        {
            
            int test = 0;
            for (int i = 0; i < Tim.Rows.Count; i++)
            {
                if (Tim.Rows[i][1].ToString() == tb_namatim.Text)
                {
                    DialogResult bm = MessageBox.Show("Nama Tim Udah Ada", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    test++;
                    break;
                }
                if (Tim.Rows[i][2].ToString() == tb_namastadium.Text)
                {
                    DialogResult bm = MessageBox.Show("Nama Stadium Udah Ada", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    test++;
                    break;
                }
                if (Tim.Rows[i][5].ToString() == tb_namamanager.Text)
                {
                    DialogResult bm = MessageBox.Show("Nama Manager Udah Ada", "Error", MessageBoxButtons.OK,MessageBoxIcon.Error);
                    test++;
                    break;
                }
            }

            if (test != 0)
            {

            }
            else
            {
                Tim.Rows.Add(tb_ID.Text, tb_namatim.Text, tb_namastadium.Text, tb_kapasitas.Text, tb_kota.Text, tb_namamanager.Text);
                tb_ID.Text = "";
                tb_kapasitas.Text = "";
                tb_kota.Text = "";
                tb_namamanager.Text = "";
                tb_namatim.Text = "";
                tb_namastadium.Text = "";
            }
        }
        int tes = 0;
        int d = 0;
        private void tb_namatim_TextChanged(object sender, EventArgs e)
        {
            if (tb_namatim.Text != "")
            {
                char a = tb_namatim.Text[0];
                string b = a.ToString().ToUpper();

                for (int i = 0; i < Tim.Rows.Count; i++)
                {
                    if (Tim.Rows[i][0].ToString()[0].ToString() == b)
                    {
                        tes++;
                    }
                }
                d++;
                if (d == 1)
                {
                    if (tes + 1 < 10)
                    {
                        tb_ID.Text = b + "0" + (tes + 1);
                    }
                    else
                    {
                        tb_ID.Text = b + (tes + 1);
                    }
                    d = 0;
                }
                tes = 0;
            }
            
        }

        private void tb_namatim_TextAlignChanged(object sender, EventArgs e)
        {
            
        }
    }
}
